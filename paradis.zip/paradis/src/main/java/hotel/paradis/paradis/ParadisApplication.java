package hotel.paradis.paradis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParadisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParadisApplication.class, args);
	}

}
