package hotel.paradis.paradis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParadisApplicationTests {

	@Test
	void contextLoads() {
	}

}
